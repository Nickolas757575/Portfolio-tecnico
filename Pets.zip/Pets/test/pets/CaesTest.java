
package pets;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


public class CaesTest {
    Caes instance;
    public CaesTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        instance = new Caes("Kleber", 5);
    }
    
    @After
    public void tearDown() {
    }

   
    @Test
    public void testFalar() {
        System.out.println("falar");
        String mensagem = "opa";
        String expResult = "Meu nome é " + "Kleber" + ", " + mensagem;
        String result = instance.falar(mensagem);
        assertEquals(expResult, result);
        
    }

   
    @Test
    public void testAndar() {
        System.out.println("andar");
        int num_passos = 50;
        boolean expResult = true;
        boolean result = instance.andar(num_passos);
        assertEquals(expResult, result);
        
    }

    
    @Test
    public void testComer() {
        System.out.println("comer");
        instance.comer();
        float expResult = 5 + 0.01f;
        assertEquals(expResult, instance.peso, 0);
    }

   
    @Test
    public void testDormir() {
        System.out.println("dormir");
        boolean expResult = false;
        boolean result = instance.dormir();
        assertEquals(expResult, result);
        
    }
    
}
